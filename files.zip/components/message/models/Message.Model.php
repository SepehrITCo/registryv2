<?php 
	class Messages extends ActiveRecord\Model {
		
	}
	
