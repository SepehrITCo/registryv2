<?php 
	class Date implements DateInterface{
		
	}