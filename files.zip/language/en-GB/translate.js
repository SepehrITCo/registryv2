var Translate = {
	"OK":"OK",
	"CANCEL":"Cancel",
	"YES":"Yes",
	"NO":"No"
}