<?php 
	class Module_datatable extends Modules{
		
	}