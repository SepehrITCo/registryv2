<?php 
	class Menus extends ActiveRecord\Model {
		 static $table_name = 'menus';
	}
	class MenuItem extends ActiveRecord\Model {
		 static $table_name = 'menu_items';
	}