<?php 
	class Download extends ActiveRecord\Model {
		
	}
	
