<?php 
	class ScheduleModel extends ActiveRecord\Model
	{ 
	static  $table_name = "schedule";
	
	}